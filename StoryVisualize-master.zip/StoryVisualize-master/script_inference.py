#python main_pororo.py --load_ckpt='40'
python main_pororo.py --eval_fid=True



